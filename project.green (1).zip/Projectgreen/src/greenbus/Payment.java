package greenbus;

import java.util.Scanner;

public class Payment {
	

  long credit;
  String expiry; 
  int cvv;
  String Name;
 
  
  String upi;
 
 int pay;
   
   Payment(){
	   
	   Scanner sc = new Scanner(System.in);
	   System.out.println("-----------------------");
	   System.out.println("    ");
	System.out.println("------  PAYMENT  ------");
	System.out.println("    ");
	   System.out.println("Enter 1 to pay with credit card");
	   System.out.println("Enter 2 to pay with UPI");
	   System.out.println("Enter 3 to pay with cash");
	    pay=sc.nextInt();
	   if(pay==1) {	 
		   System.out.println("----------------");
		   System.out.println("Enter the Credit Card No");
		   credit=sc.nextLong();
		   System.out.println("Enter the expiry date (MM/YY)");
		   expiry =sc.next();
		   System.out.println("Enter the CVV");
		   cvv=sc.nextInt();
		   System.out.println("Enter the Name on card");
		   Name=sc.next();	  
		   System.out.println("    ");
		   
		   System.out.println("Your Payment is Successful");
		   System.out.println("    ");
			System.out.println("Processing your Confirmation...");
			System.out.println("     ");
			
		   }
	   
	   if(pay==2) {
		   System.out.println("----------------");
		   System.out.println("Enter the UPI id ");
		   upi = sc.next();
		 System.out.println("    ");
		 System.out.println("Your Payment is Successful");
		   System.out.println("    ");
			System.out.println("Processing your Confirmation...");
			System.out.println("     ");
			
	   }
	   
	   if(pay==3){
		   System.out.println("----------------");
		   System.out.println("Pay the Cash while Boarding");
		   System.out.println("    ");
	   }
   }
}
