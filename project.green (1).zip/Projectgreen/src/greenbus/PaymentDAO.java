package greenbus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PaymentDAO {

	public void addpayment(Payment payment) throws SQLException {
		// TODO Auto-generated method stub
		String query = "Insert into Payment values(?,?,?,?)";
		String query1 =  "Insert into UPI values (?)";
		Connection con = DbConnection.getConnection();
		if(payment.pay==1) {
		PreparedStatement pst = con.prepareStatement(query);
		
		pst.setLong(1, payment.credit);
		pst.setString(2,payment.expiry);
		pst.setInt(3, payment.cvv);
		pst.setString(4,payment.Name);
		pst.executeUpdate();
		}
		
		if(payment.pay==2){
		PreparedStatement pst1 =con.prepareStatement(query1);
		pst1.setString(1, payment.upi);	
		//pst1.setString(2, payment.name);
		pst1.executeUpdate();
		
	}

}
}
