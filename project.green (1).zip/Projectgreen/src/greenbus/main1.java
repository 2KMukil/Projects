package greenbus;

import java.sql.SQLException;
import java.util.Scanner;

public class main1 {

	public static void main(String[] args)  {
		
		System.out.println("       Welcome to Green Bus    ");
		System.out.println("    Your Travel Friendly Partner    ");
		//System.out.println("Your OneStop Destination For Travel");
		System.out.println("--------------------------------------");
			int userOpt = 1;
			Scanner scanner = new Scanner(System.in);
					
			while(userOpt==1) {
				System.out.println("Enter 1 to Book");
				System.out.println("Enter 2 to Exit");
				userOpt = scanner.nextInt();
				if(userOpt == 1) {
					BusDAO busdao = new BusDAO();
					System.out.println("      ");
					System.out.println("---------  BUS DETAILS  --------");
						try {
							busdao.displayBusInfo();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
					Booking booking = new Booking();
					
					try { 
						if(booking.isAvailable()) {
							BookingDAO bookingdao = new BookingDAO();
							bookingdao.addBooking(booking);
							Payment payment= new Payment();
							PaymentDAO paymentdao = new PaymentDAO();
							paymentdao.addpayment(payment);
							
							
							
							System.out.println("     ");
							System.out.println("-----  BOOKING CONFIRMATION -----");
							System.out.println("  ");
							System.out.println("Hello "+booking.passengerName+", Your Booking Is Confirmed For Bus NO :"+ booking.busNo);
							System.out.println("  ");
							System.out.println("You will get a confirmation Mail on "+booking.email+" and SMS on your Mobile No :"+booking.mobileno);
							System.out.println("  ");
							System.out.println("--- HAPPY JOURNEY "+booking.passengerName+" !!!  ---");
							System.out.println(" ");
							System.out.println("--------------------");
							System.out.println(" ");
						}
						else {
							System.out.println("   ");
							System.out.println("Sorry "+booking.passengerName+", the Bus no:"+booking.busNo+" which you have selected is out of seats");
						    System.out.println("   ");
						    System.out.println("Please select a different Bus or try a different date");
						    System.out.println("   ");
						    System.out.println("-------------------------");
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else {
					System.out.println("   ");
					System.out.println(" Thank you for visiting GREEN BUS   ");
					System.out.println("    Hope You liked Our Services ");
					System.out.println("   ");
					System.out.println("----------- VISIT AGAIN -----------");
					
				}
		
			}
			scanner.close();
	}
}


	
		


